package com.example.employee.projections;
public class EmployeeSummaryImpl implements EmployeeSummary {

    private Long id;
    private String name;
    private String email;

    public EmployeeSummaryImpl(Long id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    @Override
    public Long getId() { return id; }
    @Override
    public String getName() { return name; }
    @Override
    public String getEmail() { return email; }
}

