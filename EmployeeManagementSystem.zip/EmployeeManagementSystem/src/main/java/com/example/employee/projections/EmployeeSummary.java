package com.example.employee.projections;

public interface EmployeeSummary {
    Long getId();
    String getName();
    String getEmail();
}

