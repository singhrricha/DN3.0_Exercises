package com.example.employee.config;

public class SecondaryDataSourceConfig {
    
}
