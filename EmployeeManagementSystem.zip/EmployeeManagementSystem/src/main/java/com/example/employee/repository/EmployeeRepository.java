package com.example.employee.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.employee.entity.Employee;
import com.example.employee.projections.EmployeeSummary;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // src/main/java/com/example/employee/EmployeeRepository.java
@Query("SELECT new com.example.employee.projections.EmployeeSummaryImpl(e.id, e.name, e.email) FROM Employee e WHERE e.department.id = :departmentId")
List<EmployeeSummary> findEmployeeSummariesByDepartmentId(@Param("departmentId") Long departmentId);
    List<EmployeeSummary> findByDepartmentId(Long departmentId);
}

