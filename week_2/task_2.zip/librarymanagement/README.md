# Library Management Application

## Overview

The Library Management Application is a Spring Boot-based web application designed to manage a library system. It includes functionalities for managing books, logging method executions, and utilizes Spring AOP for aspect-oriented programming.

## Table of Contents

- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [Endpoints](#endpoints)
- [License](#license)

## Getting Started

To get started with the Library Management application, you'll need to have the following installed:

- **Java Development Kit (JDK)**: Version 1.8 or above.
- **Maven**: For dependency management and building the project.

Clone the repository and navigate into the project directory:

```bash
git clone https://github.com/yourusername/library-management.git
cd library-management
```

## Project Structure

Here is an overview of the project's directory structure:

```
LibraryManagement/
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── library/
│   │   │           ├── LibraryManagementApplication.java
│   │   │           ├── aspect/
│   │   │           │   └── LoggingAspect.java
│   │   │           ├── controller/
│   │   │           │   └── BookController.java
│   │   │           ├── entity/
│   │   │           │   └── Book.java
│   │   │           ├── repository/
│   │   │           │   └── BookRepository.java
│   │   │           └── service/
│   │   │               └── BookService.java
│   │   ├── resources/
│   │   │   ├── application.properties
│   │   │   └── applicationContext.xml
│   └── test/
│       └── java/
│           └── com/
│               └── library/
│                   └── LibraryManagementApplicationTests.java
```

## Configuration

### `application.properties`

Contains the configuration for the H2 in-memory database:

```properties
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driver-class-name=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.h2.console.enabled=true
```

### `applicationContext.xml`

XML configuration for Spring:

```xml
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd
                           http://www.springframework.org/schema/aop
                           http://www.springframework.org/schema/aop/spring-aop.xsd">

    <bean id="bookRepository" class="com.library.repository.BookRepository"/>

    <bean id="bookService" class="com.library.service.BookService">
        <constructor-arg ref="bookRepository"/>
    </bean>

    <aop:aspectj-autoproxy/>
    <bean id="loggingAspect" class="com.library.aspect.LoggingAspect"/>
</beans>
```

## Running the Application

1. **Build the Project**:

   Run the following command to build the project:

   ```bash
   mvn clean install
   ```

2. **Run the Spring Boot Application**:

   You can run the application using the following command:

   ```bash
   mvn spring-boot:run
   ```

   Alternatively, you can run it from your IDE by executing the `LibraryManagementApplication` class.

## Endpoints

The application provides RESTful endpoints to manage books:

- **GET /books**: Retrieve all books.
- **POST /books**: Create a new book.
- **GET /books/{id}**: Retrieve a book by ID.
- **PUT /books/{id}**: Update an existing book.
- **DELETE /books/{id}**: Delete a book by ID.

