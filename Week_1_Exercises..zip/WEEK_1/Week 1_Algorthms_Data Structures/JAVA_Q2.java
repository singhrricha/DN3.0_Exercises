//Q2
package practice;
import java.util.Arrays;

public class JAVA_Q2 {
	
	public class Product {
	    private int productId;
	    private String productName;
	    private String category;

	    public Product(int productId, String productName, String category) {
	        this.productId = productId;
	        this.productName = productName;
	        this.category = category;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    @Override
	    public String toString() {
	        return "Product{" +
	                "productId=" + productId +
	                ", productName='" + productName + '\'' +
	                ", category='" + category + '\'' +
	                '}';
	    }
	}

//Q3
	public class ECommerceSearch {

	    public static Product linearSearch(Product[] products, String targetName) {
	        for (Product product : products) {
	            if (product.getProductName().equals(targetName)) {
	                return product;
	            }
	        }
	        return null;
	    }

	    public static Product binarySearch(Product[] sortedProducts, String targetName) {
	        int left = 0;
	        int right = sortedProducts.length - 1;

	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            int comparison = sortedProducts[mid].getProductName().compareTo(targetName);

	            if (comparison == 0) {
	                return sortedProducts[mid];
	            } else if (comparison < 0) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return null;
	    }

	    public static void main(String[] args) {
	        Product[] products = {
	            new Product(1, "Laptop", "Electronics"),
	            new Product(2, "T-shirt", "Clothing"),
	            new Product(3, "Book", "Literature")
	        };

	        // Linear search
	        Product linearResult = linearSearch(products, "T-shirt");
	        System.out.println("Linear Search Result: " + linearResult);

	        // Sort products for binary search
	        Product[] sortedProducts = Arrays.copyOf(products, products.length);
	        Arrays.sort(sortedProducts, (a, b) -> a.getProductName().compareTo(b.getProductName()));

	        // Binary search
	        Product binaryResult = binarySearch(sortedProducts, "T-shirt");
	        System.out.println("Binary Search Result: " + binaryResult);
	    }
	}

}
