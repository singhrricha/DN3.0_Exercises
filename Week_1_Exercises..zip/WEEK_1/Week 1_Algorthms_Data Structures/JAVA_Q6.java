package practice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class JAVA_Q6 {
//Q2
	public class Book {
	    private int bookId;
	    private String title;
	    private String author;

	    public Book(int bookId, String title, String author) {
	        this.bookId = bookId;
	        this.title = title;
	        this.author = author;
	    }

	    // Getters
	    public int getBookId() { return bookId; }
	    public String getTitle() { return title; }
	    public String getAuthor() { return author; }

	    @Override
	    public String toString() {
	        return "Book{" +
	                "bookId=" + bookId +
	                ", title='" + title + '\'' +
	                ", author='" + author + '\'' +
	                '}';
	    }
	}
//Q3

	public class LibraryManagementSystem {
	    private List<Book> books;

	    public LibraryManagementSystem() {
	        books = new ArrayList<>();
	    }

	    public void addBook(Book book) {
	        books.add(book);
	    }

	    public Book linearSearchByTitle(String title) {
	        for (Book book : books) {
	            if (book.getTitle().equalsIgnoreCase(title)) {
	                return book;
	            }
	        }
	        return null;
	    }

	    public Book binarySearchByTitle(String title) {
	        // Sort the books by title
	        Collections.sort(books, Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER));

	        int left = 0;
	        int right = books.size() - 1;

	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            int comparison = books.get(mid).getTitle().compareToIgnoreCase(title);

	            if (comparison == 0) {
	                return books.get(mid);
	            } else if (comparison < 0) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return null;
	    }

	    public static void main(String[] args) {
	        LibraryManagementSystem lms = new LibraryManagementSystem();

	        lms.addBook(new Book(1, "To Kill a Mockingbird", "Harper Lee"));
	        lms.addBook(new Book(2, "1984", "George Orwell"));
	        lms.addBook(new Book(3, "Pride and Prejudice", "Jane Austen"));
	        lms.addBook(new Book(4, "The Great Gatsby", "F. Scott Fitzgerald"));

	        String searchTitle = "1984";

	        // Linear search
	        long startTime = System.nanoTime();
	        Book linearResult = lms.linearSearchByTitle(searchTitle);
	        long linearTime = System.nanoTime() - startTime;

	        System.out.println("Linear Search Result: " + linearResult);
	        System.out.println("Linear Search Time: " + linearTime + " ns");

	        // Binary search
	        startTime = System.nanoTime();
	        Book binaryResult = lms.binarySearchByTitle(searchTitle);
	        long binaryTime = System.nanoTime() - startTime;

	        System.out.println("\nBinary Search Result: " + binaryResult);
	        System.out.println("Binary Search Time: " + binaryTime + " ns");
	    }
	}
}
