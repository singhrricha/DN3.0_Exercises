package practice;
//Q2
public class JAVA_Q7 {
	//Q2
	public class FinancialForecaster {

	  
	    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
	        
	        if (years == 0) {
	            return presentValue;
	        }
	        
	
	        return calculateFutureValue(presentValue, growthRate, years - 1) * (1 + growthRate);
	    }


	    public static void main(String[] args) {
	        double initialValue = 1000;
	        double annualGrowthRate = 0.05; // 5% growth rate
	        int yearsToForecast = 5;

	        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, yearsToForecast);
	        System.out.printf("Future value after %d years: $%.2f%n", yearsToForecast, futureValue);
	    }
	}

}
