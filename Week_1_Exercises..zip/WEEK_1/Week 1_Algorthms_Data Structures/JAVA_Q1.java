//Q3.
package practice;
import java.util.HashMap;
import java.util.Map;

public class JAVA_Q1 {


	class Product {
	    private String productId;
	    private String productName;
	    private int quantity;
	    private double price;

	    public Product(String productId, String productName, int quantity, double price) {
	        this.productId = productId;
	        this.productName = productName;
	        this.quantity = quantity;
	        this.price = price;
	    }

	    // Getters and setters
	    public String getProductId() { return productId; }
	    public String getProductName() { return productName; }
	    public int getQuantity() { return quantity; }
	    public void setQuantity(int quantity) { this.quantity = quantity; }
	    public double getPrice() { return price; }
	    public void setPrice(double price) { this.price = price; }

	    @Override
	    public String toString() {
	        return "Product{" +
	                "productId='" + productId + '\'' +
	                ", productName='" + productName + '\'' +
	                ", quantity=" + quantity +
	                ", price=" + price +
	                '}';
	    }
	}

	public class InventoryManagementSystem {
	    private Map<String, Product> inventory;

	    public InventoryManagementSystem() {
	        inventory = new HashMap<>();
	    }

	    public void addProduct(Product product) {
	        inventory.put(product.getProductId(), product);
	    }

	    public void updateProduct(String productId, int newQuantity, double newPrice) {
	        if (inventory.containsKey(productId)) {
	            Product product = inventory.get(productId);
	            product.setQuantity(newQuantity);
	            product.setPrice(newPrice);
	        } else {
	            System.out.println("Product not found in inventory.");
	        }
	    }

	    public void deleteProduct(String productId) {
	        if (inventory.remove(productId) == null) {
	            System.out.println("Product not found in inventory.");
	        }
	    }

	    public Product getProduct(String productId) {
	        return inventory.get(productId);
	    }

	    public void displayInventory() {
	        for (Product product : inventory.values()) {
	            System.out.println(product);
	        }
	    }

	    public static void main(String[] args) {
	        InventoryManagementSystem ims = new InventoryManagementSystem();

	        // Adding products
	        ims.addProduct(new Product("P001", "Laptop", 10, 999.99));
	        ims.addProduct(new Product("P002", "Smartphone", 20, 499.99));
	        ims.addProduct(new Product("P003", "Headphones", 50, 79.99));

	        System.out.println("Initial Inventory:");
	        ims.displayInventory();

	        // Updating a product
	        ims.updateProduct("P001", 15, 1099.99);

	        // Deleting a product
	        ims.deleteProduct("P002");

	        System.out.println("\nUpdated Inventory:");
	        ims.displayInventory();
	    }
	}

}

