package practice;
//Q2
public class JAVA_Q5 {
	public class Task {
	    private int taskId;
	    private String taskName;
	    private String status;

	    public Task(int taskId, String taskName, String status) {
	        this.taskId = taskId;
	        this.taskName = taskName;
	        this.status = status;
	    }

	    // Getters
	    public int getTaskId() { return taskId; }
	    public String getTaskName() { return taskName; }
	    public String getStatus() { return status; }

	    @Override
	    public String toString() {
	        return "Task{" +
	                "taskId=" + taskId +
	                ", taskName='" + taskName + '\'' +
	                ", status='" + status + '\'' +
	                '}';
	    }
	}
	//Q3
	public class TaskManager {
	    private class Node {
	        Task task;
	        Node next;

	        Node(Task task) {
	            this.task = task;
	            this.next = null;
	        }
	    }

	    private Node head;

	    public TaskManager() {
	        head = null;
	    }

	    public void add(Task task) {
	        Node newNode = new Node(task);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    public Task search(int taskId) {
	        Node current = head;
	        while (current != null) {
	            if (current.task.getTaskId() == taskId) {
	                return current.task;
	            }
	            current = current.next;
	        }
	        return null;
	    }

	    public void traverse() {
	        Node current = head;
	        while (current != null) {
	            System.out.println(current.task);
	            current = current.next;
	        }
	    }

	    public boolean delete(int taskId) {
	        if (head == null) return false;

	        if (head.task.getTaskId() == taskId) {
	            head = head.next;
	            return true;
	        }

	        Node current = head;
	        while (current.next != null) {
	            if (current.next.task.getTaskId() == taskId) {
	                current.next = current.next.next;
	                return true;
	            }
	            current = current.next;
	        }
	        return false;
	    }

	    public static void main(String[] args) {
	        TaskManager tm = new TaskManager();

	        tm.add(new Task(1, "Complete project", "In Progress"));
	        tm.add(new Task(2, "Review code", "Pending"));
	        tm.add(new Task(3, "Write documentation", "Not Started"));

	        System.out.println("All tasks:");
	        tm.traverse();

	        Task found = tm.search(2);
	        System.out.println("\nFound task: " + found);

	        boolean deleted = tm.delete(1);
	        System.out.println("\nTask deleted: " + deleted);

	        System.out.println("\nTasks after deletion:");
	        tm.traverse();
	    }
	}

}
