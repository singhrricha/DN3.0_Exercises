//Exercise 4: Implementing the Adapter Pattern
package practice;

public class design_pattern_Q4 {

	public interface Animal {
	    void eat();
	    void sleep();
	}

	public class Dog implements Animal {
	    @Override
	    public void eat() {
	        System.out.println("Dog is eating");
	    }

	    @Override
	    public void sleep() {
	        System.out.println("Dog is sleeping");
	    }
	}

	public class Cat implements Animal {
	    @Override
	    public void eat() {
	        System.out.println("Cat is eating");
	    }

	    @Override
	    public void sleep() {
	        System.out.println("Cat is sleeping");
	    }
	}

	public interface AnimalFactory {
	    Animal createAnimal();
	}

	public class DogFactory implements AnimalFactory {
	    @Override
	    public Animal createAnimal() {
	        return new Dog();
	    }
	}


	public class CatFactory implements AnimalFactory {
	    @Override
	    public Animal createAnimal() {
	        return new Cat();
	    }
	}


	public class AnimalFactoryClient {
	    public static void main(String[] args) {
	        AnimalFactory dogFactory = new DogFactory();
	        Animal dog = dogFactory.createAnimal();
	        dog.eat();
	        dog.sleep();

	        AnimalFactory catFactory = new CatFactory();
	        Animal cat = catFactory.createAnimal();
	        cat.eat();
	        cat.sleep();
	    }
	}
}