// Implementing the Strategy Pattern
package practice;

public class DESIGN_PATTERN_Q8 {

	interface Strategy {
	    int execute(int num1, int num2);
	}

	class AdditionStrategy implements Strategy {
	    @Override
	    public int execute(int num1, int num2) {
	        return num1 + num2;
	    }
	}


	class SubtractionStrategy implements Strategy {
	    @Override
	    public int execute(int num1, int num2) {
	        return num1 - num2;
	    }
	}

	class MultiplicationStrategy implements Strategy {
	    @Override
	    public int execute(int num1, int num2) {
	        return num1 * num2;
	    }
	}

	class DivisionStrategy implements Strategy {
	    @Override
	    public int execute(int num1, int num2) {
	        if (num2 != 0) {
	            return num1 / num2;
	        } else {
	            throw new ArithmeticException("Division by zero");
	        }
	    }
	}

	class Context {
	    private Strategy strategy;

	    public Context(Strategy strategy) {
	        this.strategy = strategy;
	    }

	    public int executeStrategy(int num1, int num2) {
	        return strategy.execute(num1, num2);
	    }
	}

	public class StrategyPatternTest {
	    public static void main(String[] args) {
	        Context context = new Context(new AdditionStrategy());
	        System.out.println("Result of addition: " + context.executeStrategy(10, 5));

	        context = new Context(new SubtractionStrategy());
	        System.out.println("Result of subtraction: " + context.executeStrategy(10, 5));

	        context = new Context(new MultiplicationStrategy());
	        System.out.println("Result of multiplication: " + context.executeStrategy(10, 5));

	        context = new Context(new DivisionStrategy());
	        System.out.println("Result of division: " + context.executeStrategy(10, 5));
	    }
	}
}