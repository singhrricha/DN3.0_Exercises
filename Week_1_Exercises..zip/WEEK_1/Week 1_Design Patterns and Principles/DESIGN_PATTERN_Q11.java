package practice;
//Implementing Dependency Injection
public class DESIGN_PATTERN_Q11 {

	interface Observer {
	    void update();
	}


	interface Observable {
	    void addObserver(Observer observer);
	    void removeObserver(Observer observer);
	    void notifyObservers();
	}


	class Subject implements Observable {
	    private String subjectState;
	    private Observer observerList[];
	    private int observerCount;

	    public Subject() {
	        observerList = new Observer[5];
	        observerCount = 0;
	    }

	    public void addObserver(Observer observer) {
	        observerList[observerCount++] = observer;
	    }

	    public void removeObserver(Observer observer) {
	        for (int i = 0; i < observerCount; i++) {
	            if (observerList[i] == observer) {
	                observerList[i] = observerList[--observerCount];
	            }
	        }
	    }

	    public void notifyObservers() {
	        for (int i = 0; i < observerCount; i++) {
	            observerList[i].update();
	        }
	    }

	    public void setSubjectState(String subjectState) {
	        this.subjectState = subjectState;
	        notifyObservers();
	    }

	    public String getSubjectState() {
	        return subjectState;
	    }
	}


	class ObserverA implements Observer {
	    @Override
	    public void update() {
	        System.out.println("ObserverA: Subject's state changed to: " + ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) ((Subject) subject)).getSubjectState())));
	    }
	}


	class ObserverB implements Observer {
	    @Override
	    public void update() {
	        System.out.println("ObserverB: Subject's state changed to: " + ((Subject) subject).getSubjectState());
	    }
	}

	
	public class ObserverPatternTest {
	    public static void main(String[] args) {
	        Subject subject = new Subject();

	        ObserverA observerA = new ObserverA();
	        ObserverB observerB = new ObserverB();

	        subject.addObserver(observerA);
	        subject.addObserver(observerB);

	        subject.setSubjectState("Set state 1");
	        subject.setSubjectState("Set state 2");

	        subject.removeObserver(observerA);

	        subject.setSubjectState("Set state 3");
	    }
	}

}
