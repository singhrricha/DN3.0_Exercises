package practice;

import java.net.URL;

public class design_pattern_Q6 {


	interface Image {
	    void display();
	}

	class RealImage implements Image {
	    private String url;

	    public RealImage(String url) {
	        this.url = url;
	    }

	    @Override
	    public void display() {
	        System.out.println("Loading image from URL: " + url);
	        try {
	            Thread.sleep(1000); // Simulate loading time
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        System.out.println("Image loaded from URL: " + url);
	    }
	}

	class ProxyImage implements Image {
	    private String url;
	    private RealImage realImage;

	    public ProxyImage(String url) {
	        this.url = url;
	    }

	    @Override
	    public void display() {
	        if (realImage == null) {
	            realImage = new RealImage(url);
	        }
	        realImage.display();
	    }
	}

	public class ProxyPatternTest {
	    public static void main(String[] args) {

	        Image image1 = new ProxyImage("https://example.com/image1.jpg");
	        Image image2 = new ProxyImage("https://example.com/image2.jpg");

	        image1.display();
	        image2.display();

	        image1.display();
	        image2.display();
	    }
	}
}