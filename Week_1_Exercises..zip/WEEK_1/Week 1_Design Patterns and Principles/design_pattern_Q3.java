//Exercise 3: Implementing the Builder Pattern
package practice;

public class design_pattern_Q3 {

	public class Computer {
	    private String cpu;
	    private int ram;
	    private String storage;


	    private Computer(Builder builder) {
	        this.cpu = builder.cpu;
	        this.ram = builder.ram;
	        this.storage = builder.storage;
	    }

	    public String getCpu() {
	        return cpu;
	    }

	    public int getRam() {
	        return ram;
	    }

	    public String getStorage() {
	        return storage;
	    }

	    public static class Builder {
	        private String cpu;
	        private int ram;
	        private String storage;

	        public Builder setCpu(String cpu) {
	            this.cpu = cpu;
	            return this;
	        }

	        public Builder setRam(int ram) {
	            this.ram = ram;
	            return this;
	        }

	        public Builder setStorage(String storage) {
	            this.storage = storage;
	            return this;
	        }

	        public Computer build() {
	            return new Computer(this);
	        }
	    }
	}


	public class BuilderPatternTest {
	    public static void main(String[] args) {

	        Computer basicComputer = new Computer.Builder()
	               .setCpu("Intel Core i3")
	               .setRam(8)
	               .setStorage("256GB SSD")
	               .build();

	        System.out.println("Basic Computer Configuration:");
	        System.out.println("CPU: " + basicComputer.getCpu());
	        System.out.println("RAM: " + basicComputer.getRam() + "GB");
	        System.out.println("Storage: " + basicComputer.getStorage());


	        Computer highEndComputer = new Computer.Builder()
	               .setCpu("Intel Core i9")
	               .setRam(16)
	               .setStorage("1TB SSD")
	               .build();

	        System.out.println("\nHigh-End Computer Configuration:");
	        System.out.println("CPU: " + highEndComputer.getCpu());
	        System.out.println("RAM: " + highEndComputer.getRam() + "GB");
	        System.out.println("Storage: " + highEndComputer.getStorage());
	    }
	}

}
