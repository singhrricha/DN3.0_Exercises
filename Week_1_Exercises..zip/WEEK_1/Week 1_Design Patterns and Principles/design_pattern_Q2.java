//Exercise 2: Implementing the Factory Method Pattern
package practice;

public class design_pattern_Q2 {

	public interface Document {
	    void open();
	    void close();
	}


	public class WordDocument implements Document {
	    @Override
	    public void open() {
	        System.out.println("Opening a Word document");
	    }

	    @Override
	    public void close() {
	        System.out.println("Closing a Word document");
	    }
	}


	public class PdfDocument implements Document {
	    @Override
	    public void open() {
	        System.out.println("Opening a PDF document");
	    }

	    @Override
	    public void close() {
	        System.out.println("Closing a PDF document");
	    }
	}


	public interface DocumentFactory {
	    Document createDocument();
	}

	public class WordDocumentFactory implements DocumentFactory {
	    @Override
	    public Document createDocument() {
	        return new WordDocument();
	    }
	}


	public class PdfDocumentFactory implements DocumentFactory {
	    @Override
	    public Document createDocument() {
	        return new PdfDocument();
	    }
	}


	public class DocumentFactoryClient {
	    public static void main(String[] args) {
	        DocumentFactory wordFactory = new WordDocumentFactory();
	        Document wordDocument = wordFactory.createDocument();
	        wordDocument.open();
	        wordDocument.close();

	        DocumentFactory pdfFactory = new PdfDocumentFactory();
	        Document pdfDocument = pdfFactory.createDocument();
	        pdfDocument.open();
	        pdfDocument.close();
	    }
	}
}